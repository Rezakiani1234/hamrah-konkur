import 'dart:async';
import 'dart:ui' show FontFeature;
import 'package:flutter/material.dart';

void main() => runApp(const KonkurApp());

const Color ink = Color(0xFF0B1020);
const Color panel = Color(0xFF151D32);
const Color panel2 = Color(0xFF1D2942);
const Color violet = Color(0xFF9B8CFF);
const Color mint = Color(0xFF6DE0C2);

class KonkurApp extends StatelessWidget {
  const KonkurApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'همراه کنکور',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: ink,
        colorScheme: ColorScheme.fromSeed(seedColor: violet, brightness: Brightness.dark),
        cardTheme: const CardThemeData(color: panel, elevation: 0, margin: EdgeInsets.zero),
        fontFamily: 'Roboto',
      ),
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selected = 0;
  final pages = const [
    DashboardPage(), PlannerPage(), StudyPage(), TestsPage(), ProgressPage(),
  ];
  final labels = const ['خانه', 'برنامه', 'مطالعه', 'آزمون', 'پیشرفت'];
  final icons = const [Icons.grid_view_rounded, Icons.calendar_month_rounded, Icons.timer_rounded, Icons.quiz_rounded, Icons.insights_rounded];

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: IndexedStack(index: selected, children: pages)),
    bottomNavigationBar: NavigationBar(
      backgroundColor: panel,
      indicatorColor: violet.withValues(alpha: .18),
      selectedIndex: selected,
      onDestinationSelected: (v) => setState(() => selected = v),
      destinations: List.generate(labels.length, (i) => NavigationDestination(icon: Icon(icons[i]), label: labels[i])),
    ),
  );
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('همراه کنکور', style: TextStyle(color: Colors.white70, fontSize: 14)),
        SizedBox(height: 5), Text('سلام، آماده‌ای؟', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800)),
      ])),
      CircleAvatar(radius: 24, backgroundColor: panel2, child: Icon(Icons.person_rounded, color: violet, size: 28)),
    ]),
    const SizedBox(height: 22),
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFF383064), Color(0xFF202B49)], begin: Alignment.topRight, end: Alignment.bottomLeft),
      borderRadius: BorderRadius.circular(24),
    ), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('هدف امروز', style: TextStyle(color: Colors.white70)),
      SizedBox(height: 8), Text('۶ ساعت مطالعه مفید', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
      SizedBox(height: 18), LinearProgressIndicator(value: .32, minHeight: 8, borderRadius: BorderRadius.all(Radius.circular(20)), backgroundColor: Colors.white12, color: mint),
      SizedBox(height: 8), Text('۱ ساعت و ۵۵ دقیقه از هدف امروز', style: TextStyle(color: Colors.white70, fontSize: 12)),
    ])),
    const SizedBox(height: 22),
    const SectionTitle(title: 'خلاصه امروز', subtitle: 'شروع کوچک بهتر از شروع نکردن است'),
    const SizedBox(height: 12),
    const Row(children: [
      Expanded(child: MetricCard(icon: Icons.timer_outlined, title: 'مطالعه', value: '۱:۵۵', color: mint)),
      SizedBox(width: 10), Expanded(child: MetricCard(icon: Icons.check_circle_outline, title: 'تست پاسخ‌داده', value: '۳۲', color: violet)),
    ]),
    const SizedBox(height: 10),
    const Row(children: [
      Expanded(child: MetricCard(icon: Icons.local_fire_department_outlined, title: 'روزهای پیوسته', value: '۴ روز', color: Color(0xFFFFB86B))),
      SizedBox(width: 10), Expanded(child: MetricCard(icon: Icons.flag_outlined, title: 'جلسه باقی‌مانده', value: '۳ جلسه', color: Color(0xFF7FB7FF))),
    ]),
    const SizedBox(height: 24),
    const SectionTitle(title: 'قدم بعدی', subtitle: 'پیشنهاد اولیه برای امروز'),
    const SizedBox(height: 12),
    const TaskTile(subject: 'زیست‌شناسی', detail: 'گفتار ۱ · مطالعه و خلاصه‌نویسی', time: '۴۵ دقیقه', color: mint),
    const SizedBox(height: 10),
    const TaskTile(subject: 'شیمی', detail: 'پیوندهای شیمیایی · ۱۵ تست', time: '۳۵ دقیقه', color: violet),
    const SizedBox(height: 10),
    const TaskTile(subject: 'فیزیک', detail: 'تمرین‌های حرکت‌شناسی', time: '۴۰ دقیقه', color: Color(0xFFFFB86B)),
    const SizedBox(height: 20),
    const Text('توجه: این برنامه نمونه است؛ برنامه‌ریزی واقعی پس از دریافت سطح، زمان آزاد و نتیجه آزمون‌ها شخصی‌سازی می‌شود.', style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.6)),
  ]);
}

class PlannerPage extends StatefulWidget {
  const PlannerPage({super.key});
  @override
  State<PlannerPage> createState() => _PlannerPageState();
}

class _PlannerPageState extends State<PlannerPage> {
  double hours = 6;
  String priority = 'متعادل';
  bool generated = false;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const PageHeading(title: 'برنامه‌ریز هوشمند', subtitle: 'برنامه پیشنهادی را با زمان و اولویتت تنظیم کن.'),
    const SizedBox(height: 22),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('چند ساعت در روز وقت داری؟', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
      const SizedBox(height: 12),
      Text('${hours.round()} ساعت', style: const TextStyle(fontSize: 25, color: violet, fontWeight: FontWeight.bold)),
      Slider(value: hours, min: 2, max: 12, divisions: 10, label: '${hours.round()} ساعت', onChanged: (v) => setState(() { hours = v; generated = false; })),
      const SizedBox(height: 10),
      const Text('نوع اولویت‌بندی', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      Wrap(spacing: 8, children: ['متعادل', 'زیست و شیمی', 'درس‌های ضعیف'].map((s) => ChoiceChip(label: Text(s), selected: priority == s, onSelected: (_) => setState(() { priority = s; generated = false; })).toList()),
      const SizedBox(height: 18),
      FilledButton.icon(onPressed: () => setState(() => generated = true), icon: const Icon(Icons.auto_awesome), label: const Text('ساخت برنامه پیشنهادی')),
    ]))),
    const SizedBox(height: 18),
    if (generated) ...[
      const SectionTitle(title: 'برنامه پیشنهادی امروز', subtitle: 'نسخه اولیه؛ هنوز بر اساس آزمون‌ها تنظیم نشده است'),
      const SizedBox(height: 12),
      ..._makePlan(hours.round(), priority).map((e) => Padding(padding: const EdgeInsets.only(bottom: 10), child: TaskTile(subject: e.$1, detail: e.$2, time: e.$3, color: e.$4))),
    ] else const EmptyHint(icon: Icons.auto_awesome, title: 'برنامه‌ات را بساز', text: 'زمان روزانه و اولویت درسی را انتخاب کن تا یک برنامه نمونه ساخته شود.'),
  ]);

  List<(String, String, String, Color)> _makePlan(int h, String p) {
    final subjects = p == 'زیست و شیمی'
      ? [('زیست‌شناسی', 'مطالعه مفهومی + تست', mint), ('شیمی', 'آموزش و تمرین', violet), ('فیزیک', 'حل مسئله', const Color(0xFFFFB86B)), ('ریاضی', 'تمرین منتخب', const Color(0xFF7FB7FF))]
      : p == 'درس‌های ضعیف'
      ? [('درس ضعیف اول', 'یادگیری مبحث دشوار', mint), ('درس ضعیف دوم', 'تمرین هدایت‌شده', violet), ('زیست‌شناسی', 'مرور و تست', const Color(0xFFFFB86B)), ('شیمی', 'مرور نکته‌ها', const Color(0xFF7FB7FF))]
      : [('زیست‌شناسی', 'مطالعه مفهومی + تست', mint), ('شیمی', 'آموزش و تمرین', violet), ('فیزیک', 'حل مسئله', const Color(0xFFFFB86B)), ('ریاضی', 'تمرین منتخب', const Color(0xFF7FB7FF))];
    final mins = h * 60;
    final per = (mins / subjects.length).round();
    return subjects.map((s) => (s.$1, s.$2, '$per دقیقه', s.$3)).toList();
  }
}

class StudyPage extends StatefulWidget {
  const StudyPage({super.key});
  @override
  State<StudyPage> createState() => _StudyPageState();
}

class _StudyPageState extends State<StudyPage> {
  Timer? timer;
  int seconds = 0;
  bool running = false;
  String subject = 'زیست‌شناسی';
  @override
  void dispose() { timer?.cancel(); super.dispose(); }
  String get formatted => '${(seconds ~/ 3600).toString().padLeft(2, '0')}:${((seconds % 3600) ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';
  void toggle() {
    if (running) { timer?.cancel(); setState(() => running = false); }
    else { timer = Timer.periodic(const Duration(seconds: 1), (_) => setState(() => seconds++)); setState(() => running = true); }
  }
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const PageHeading(title: 'جلسه مطالعه', subtitle: 'زمان مطالعه مفیدت را ثبت کن.'),
    const SizedBox(height: 28),
    Container(padding: const EdgeInsets.symmetric(vertical: 34, horizontal: 20), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(28), border: Border.all(color: violet.withValues(alpha: .25))), child: Column(children: [
      const Icon(Icons.hourglass_bottom_rounded, color: violet, size: 34),
      const SizedBox(height: 18),
      Text(formatted, style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w700, fontFeatures: [FontFeature.tabularFigures()])),
      const SizedBox(height: 20),
      DropdownButtonFormField<String>(value: subject, decoration: const InputDecoration(labelText: 'درس جلسه', border: OutlineInputBorder()), items: ['زیست‌شناسی', 'شیمی', 'فیزیک', 'ریاضی', 'زمین‌شناسی', 'عمومی و ترمیم معدل'].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(), onChanged: running ? null : (v) => setState(() => subject = v ?? subject)),
      const SizedBox(height: 22),
      Row(children: [Expanded(child: FilledButton.icon(onPressed: toggle, icon: Icon(running ? Icons.pause_rounded : Icons.play_arrow_rounded), label: Text(running ? 'توقف' : 'شروع مطالعه'))), const SizedBox(width: 10), OutlinedButton(onPressed: () { timer?.cancel(); setState(() { seconds = 0; running = false; }); }, child: const Text('بازنشانی'))]),
    ])),
    const SizedBox(height: 18),
    const EmptyHint(icon: Icons.tips_and_updates_outlined, title: 'قانون جلسه', text: 'هنگام وقفه طولانی تایمر را متوقف کن. در نسخه بعدی، جلسات ذخیره می‌شوند و به گزارش روزانه اضافه خواهند شد.'),
  ]);
}

class TestsPage extends StatelessWidget {
  const TestsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const PageHeading(title: 'تست و آزمون', subtitle: 'تمرین هدفمند، نه فقط تعداد تست بیشتر.'),
    const SizedBox(height: 20),
    const TaskTile(subject: 'آزمون موضوعی', detail: 'انتخاب درس، پایه و مبحث', time: 'قابل تنظیم', color: mint),
    const SizedBox(height: 10), const TaskTile(subject: 'آزمون زمان‌دار', detail: 'شبیه‌سازی شرایط آزمون', time: 'زمان‌دار', color: violet),
    const SizedBox(height: 10), const TaskTile(subject: 'دفترچه اشتباهات', detail: 'ثبت علت اشتباه و زمان مرور بعدی', time: 'همیشه در دسترس', color: const Color(0xFFFFB86B)),
    const SizedBox(height: 20),
    const EmptyHint(icon: Icons.library_books_outlined, title: 'بانک سؤال هنوز متصل نیست', text: 'برای آزمون واقعی باید سؤال‌های معتبر، پاسخ‌های تشریحی و منبع هر سؤال به برنامه اضافه شوند. سؤال ساختگی به‌عنوان سؤال رسمی نمایش داده نمی‌شود.'),
  ]);
}

class ProgressPage extends StatelessWidget {
  const ProgressPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const PageHeading(title: 'پیشرفت من', subtitle: 'نمونه نمایشی شاخص‌هایی که ثبت خواهیم کرد.'),
    const SizedBox(height: 20),
    const MetricCard(icon: Icons.timer_outlined, title: 'مطالعه این هفته', value: '۲۱ ساعت', color: mint),
    const SizedBox(height: 10), const MetricCard(icon: Icons.fact_check_outlined, title: 'تست‌های ثبت‌شده', value: '۲۴۶', color: violet),
    const SizedBox(height: 10), const MetricCard(icon: Icons.trending_up_rounded, title: 'پایبندی به برنامه', value: '۷۸٪', color: const Color(0xFFFFB86B)),
    const SizedBox(height: 20),
    const EmptyHint(icon: Icons.insights_rounded, title: 'تحلیل دقیق پس از ثبت داده‌ها', text: 'پیش‌بینی رتبه یا درصد بدون داده واقعی قابل اعتماد نیست. تحلیل نهایی باید از نتایج آزمون‌ها و روند چند هفته‌ای استفاده کند.'),
  ]);
}

class PageHeading extends StatelessWidget {
  final String title, subtitle;
  const PageHeading({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w800)), const SizedBox(height: 7), Text(subtitle, style: const TextStyle(color: Colors.white60, height: 1.5))]);
}

class SectionTitle extends StatelessWidget {
  final String title, subtitle;
  const SectionTitle({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 12))]);
}

class MetricCard extends StatelessWidget {
  final IconData icon; final String title, value; final Color color;
  const MetricCard({super.key, required this.icon, required this.title, required this.value, required this.color});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: color), const SizedBox(height: 14), Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 4), Text(title, style: const TextStyle(color: Colors.white60, fontSize: 12))]));
}

class TaskTile extends StatelessWidget {
  final String subject, detail, time; final Color color;
  const TaskTile({super.key, required this.subject, required this.detail, required this.time, required this.color});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(17)), child: Row(children: [Container(width: 4, height: 48, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(5))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(subject, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 5), Text(detail, style: const TextStyle(color: Colors.white60, fontSize: 12))])), const SizedBox(width: 8), Text(time, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.bold))]));
}

class EmptyHint extends StatelessWidget {
  final IconData icon; final String title, text;
  const EmptyHint({super.key, required this.icon, required this.title, required this.text});
  @override
  Widget build(BuildContext context) => Container(width: double.infinity, padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: panel.withValues(alpha: .7), borderRadius: BorderRadius.circular(20)), child: Column(children: [Icon(icon, color: violet, size: 30), const SizedBox(height: 10), Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 7), Text(text, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60, fontSize: 12, height: 1.7))]));
}
